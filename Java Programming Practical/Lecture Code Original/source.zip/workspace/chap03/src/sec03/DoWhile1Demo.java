package sec03;

public class DoWhile1Demo {
	public static void main(String[] args) {
		int i = 1;
		do {
			System.out.print(i);
			i++;
		} while (i < 5);
	}
}