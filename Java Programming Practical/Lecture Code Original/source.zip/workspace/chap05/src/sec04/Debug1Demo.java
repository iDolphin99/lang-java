package sec04;

public class Debug1Demo {
	public static void main(String[] args) {
		int d, m, n, n2, n3;
		d = 0;
		n = 2;
		// n2 = n * n:
		n2 = n * n;	
		n3 = n2 * n2;
		// m = n / d;
	}
}