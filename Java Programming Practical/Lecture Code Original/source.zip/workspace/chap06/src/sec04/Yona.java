package sec04;

public class Yona {
	public static void main(String[] args) {
		System.out.println("�ȳ�, ����!");
	}
}
