package sec06.other;

import sec06.One;

public class One2 extends One {
	void print() {
		// System.out.println(secret);
		// System.out.println(roommate);
		System.out.println(child);
		System.out.println(anybody);
	}
}
