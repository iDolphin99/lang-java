package sec03;

public interface RemoteControllable extends Controllable {
	void remoteOn();

	void remoteOff();
}