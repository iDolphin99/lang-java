package sec01;

public class UnChecked2Demo {
	public static void main(String[] args) {
		int[] array = { 0, 1, 2 };

		System.out.println(array[3]);
	}
}