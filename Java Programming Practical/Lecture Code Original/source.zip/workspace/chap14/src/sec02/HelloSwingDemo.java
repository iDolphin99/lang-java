package sec02;

import javax.swing.JFrame;

public class HelloSwingDemo {
	public static void main(String[] args) {
		JFrame f = new JFrame();

		f.setTitle("�ȳ�, ����!");
		f.setSize(300, 100);
		f.setVisible(true);
	}
}